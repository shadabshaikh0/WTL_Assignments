package com.spring;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		DatabaseConnection dc = (DatabaseConnection)context.getBean("dc");
		Student s = (Student)context.getBean("student");
		Connection conn = dc.getConnection();
		Statement st = (Statement)conn.createStatement();
		s.setRollno(101);
		s.setName("Shadab");
		String sql = "INSERT INTO student (rollno,name) values ("+ s.getRollno() +",'"+ s.getName()  +"')";
		st.execute(sql);
		
		String sql1 = "select * from student ";
		ResultSet rs =  st.executeQuery(sql1);
		while(rs.next()){
			System.out.println(rs.getString("rollno")+rs.getString("name"));
		}
		
	}

}
