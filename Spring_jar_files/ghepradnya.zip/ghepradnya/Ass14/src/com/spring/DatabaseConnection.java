package com.spring;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

	private static DatabaseDetails d;

	public void setD( DatabaseDetails d){
		this.d = d;
	}
	
	public static Connection getConnection() throws ClassNotFoundException,SQLException {
		
		Class.forName( d.getName() );
		Connection conn = (Connection)DriverManager.getConnection(d.getUrl(),"root",d.getPassword());
		return conn;
	}
}
